create function notify_watchers_ddl() returns event_trigger
    language plpgsql
as
$$
begin
  perform pg_notify(
    'postgraphile_watch',
    json_build_object(
      'type',
      'ddl',
      'payload',
      (select json_agg(json_build_object('schema', schema_name, 'command', command_tag)) from pg_event_trigger_ddl_commands() as x)
    )::text
  );
end;
$$;

alter function notify_watchers_ddl() owner to postgres;


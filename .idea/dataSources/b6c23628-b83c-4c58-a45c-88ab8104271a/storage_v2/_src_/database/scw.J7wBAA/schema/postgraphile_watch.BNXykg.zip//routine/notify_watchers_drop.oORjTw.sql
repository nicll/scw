create function notify_watchers_drop() returns event_trigger
    language plpgsql
as
$$
begin
  perform pg_notify(
    'postgraphile_watch',
    json_build_object(
      'type',
      'drop',
      'payload',
      (select json_agg(distinct x.schema_name) from pg_event_trigger_dropped_objects() as x)
    )::text
  );
end;
$$;

alter function notify_watchers_drop() owner to postgres;

